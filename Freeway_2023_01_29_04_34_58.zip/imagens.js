// imagens e sons do jogo

let imagemDaEstrada;
let imagemDoAtor;
let imagemCarro;

// sons do jogo
let somDaTrilha;
let somDaColisao;
let somDoPonto;

//imagens carros complementares
let imagemCarro2;
let imagemCarro3;
let imagemCarro4;
let imagemCarro5;

function preload(){
  imagemDaEstrada = loadImage('material/estrada.png');
  imagemDoAtor = loadImage('material/misterio.png');
  imagemCarro = loadImage('material/onibus.png');
  imagemCarro2 = loadImage('material/mercedes.png');
  imagemCarro3 = loadImage('material/download.jpeg');
  imagemCarro4 = loadImage('material/porsche.jpeg');
  imagemCarro5 = loadImage('material/caminhao.jpg');
  imagemCarro6 = loadImage('material/onibus.png');
  imagemCarros = [imagemCarro, imagemCarro2, imagemCarro3, imagemCarro4, imagemCarro5, imagemCarro6];
  
  somDaTrilha = loadSound("sons/trilha.mp3");
  somDaColisao = loadSound("sons/colidiu.mp3");
  somDoPonto = loadSound("sons/pontos.wav");
  
}